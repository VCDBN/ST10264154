package com.example.calculatorapp

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var btn_add = findViewById<Button>(R.id.btn_add)
        var opt_results = findViewById<TextView>(R.id.opt_results)
        var btn_sub = findViewById<Button>(R.id.btn_sub)
        var btn_multi = findViewById<Button>(R.id.btn_multi)
        var btn_divide = findViewById<Button>(R.id.btn_divide)
        var ipt_one = findViewById<TextView>(R.id.ipt_one)
        var ipt_two = findViewById<TextView>(R.id.ipt_two)
        val btn_clear = findViewById<Button>(R.id.btn_clear)


        btn_add.setOnClickListener {
            val num1 = ipt_one.text.toString().toInt()
            val num2 = ipt_two.text.toString().toInt()

            val result = num1 + num2
            opt_results.setText(result.toString())

        }
        btn_sub.setOnClickListener {
            val num1 = ipt_one.text.toString().toInt()
            val num2 = ipt_two.text.toString().toInt()

            val result = num1 - num2
            opt_results.setText(result.toString())

           }
        btn_multi.setOnClickListener {
            val num1 = ipt_one.text.toString().toInt()
            val num2 = ipt_two.text.toString().toInt()

            val result = num1 * num2
            opt_results.setText(result.toString())
    }
        btn_divide.setOnClickListener {
            val num1 = ipt_one.text.toString().toInt()
            val num2 = ipt_two.text.toString().toInt()

            val result = num1 / num2
            opt_results.setText(result.toString())
        }
        btn_clear.setOnClickListener{
            ipt_one.setText("")
            ipt_two.setText("")
            opt_results.setText("")
        }
    }}


